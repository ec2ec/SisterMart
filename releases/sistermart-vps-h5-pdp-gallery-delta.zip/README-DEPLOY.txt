SisterMart H5 — 商詳輪播／放大修復
================================
1. 小圓點隨滑動更新（Vant4 無 v-model:active，改 @change）
2. 放大後左右滑動跟手
3. 放大從當前第 n 張開始

備份 index.html+assets 後：unzip -o sistermart-vps-h5-pdp-gallery-delta.zip 並硬刷新
資源：index-DZdsvDWk.js index-ClTuXJBL.css
