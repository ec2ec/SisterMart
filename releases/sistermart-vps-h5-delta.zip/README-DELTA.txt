H5 delta overlay (smaller upload)
=================================
Unzip at website ROOT. Replaces index.html and adds new /assets/ + /mock/cat-*.png.
Hard refresh after upload (Ctrl+F5).
