SisterMart VPS root overlay — 2026-10-16

H5 + Admin use hash routes (#/...) so deep links work without nginx try_files.
Optional: after setting vps-spa/nginx-伪静态.conf, can switch back to history mode.

unzip -o sistermart-vps-root.zip   # at website ROOT
Then open https://sistermart.vip/  and hard refresh (Ctrl+F5).
Payment: https://sistermart.vip/#/payment/<id>
Admin:   https://sistermart.vip/admin/#/login
