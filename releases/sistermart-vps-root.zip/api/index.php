<?php
namespace think;

$backend = __DIR__ . '/../sm-backend';
$pc = $backend . '/vendor/composer/platform_check.php';
if (is_file($pc)) {
    $src = (string) file_get_contents($pc);
    if (str_contains($src, '80200') || str_contains($src, '8.2.0')) {
        file_put_contents($pc, "<?php\n// Disabled for shared-host PHP 8.1; prefer panel PHP >= 8.2\n");
    }
}
$env = $backend . '/.env';
if (!is_file($env) || filesize($env) < 10) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo "Missing sm-backend/.env — copy .env.example and fill DB credentials.\n";
    exit(1);
}

require $backend . '/vendor/autoload.php';
$http = (new App($backend . '/'))->http;
$response = $http->run();
$response->send();
$http->end($response);
