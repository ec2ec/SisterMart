SisterMart VPS root overlay — 2026-10-20T00:37Z

Contains: H5 (/) + Admin (/admin) + mock + products + API (/api/index.php → sm-backend)

unzip -o sistermart-vps-root.zip   # at website ROOT
Then hard refresh. Ensure sm-backend/.env exists on server (not shipped).

H5:    https://your-domain/
Admin: https://your-domain/admin/
API:   https://your-domain/api/index.php/api/v1/health
