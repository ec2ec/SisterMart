SisterMart VPS root overlay — 2026-11-01T14:24Z

Contains: H5 (/) + Admin (/admin) + API (/api/index.php → sm-backend)
Static:   mock/products: OMITTED (server already has them)

unzip -o sistermart-vps-root.zip   # at website ROOT (overlay; does not delete existing mock/products)
Then hard refresh. Ensure sm-backend/.env exists on server (not shipped).

Default pack skips /mock and /products. New image assets:
  INCLUDE_STATIC_ASSETS=1 pnpm build zip
  # or: pnpm build zip -- --with-static-assets

Release channel: set RELEASE_ENABLED=true and RELEASE_HMAC_SECRET in sm-backend/.env
Pack: RELEASE_HMAC_SECRET=... pnpm release pack

H5:    https://your-domain/
Admin: https://your-domain/admin/
API:   https://your-domain/api/index.php/api/v1/health
