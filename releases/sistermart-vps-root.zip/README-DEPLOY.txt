SisterMart VPS root overlay — 2026-10-22T11:07Z

Contains: H5 (/) + Admin (/admin) + mock + products + API (/api/index.php → sm-backend)

unzip -o sistermart-vps-root.zip   # at website ROOT
Then hard refresh. Ensure sm-backend/.env exists on server (not shipped).

Release channel: set RELEASE_ENABLED=true and RELEASE_HMAC_SECRET in sm-backend/.env
Pack: RELEASE_HMAC_SECRET=... pnpm release pack

H5:    https://your-domain/
Admin: https://your-domain/admin/
API:   https://your-domain/api/index.php/api/v1/health
