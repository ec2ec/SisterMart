SisterMart VPS root overlay package
====================================
Built: 2026-10-16
H5: payment check+bold, home catalog cache, circular catalog icons

Extract at FTP/website ROOT (overwrite):

  unzip -o sistermart-vps-root.zip

Layout:
  /                 H5 (index.html + /assets/)
  /admin/           Admin
  /mock/            banners, catalog icons, product images
  /products/        product static assets
  /api/index.php    API entry
  /sm-backend/      ThinkPHP app (+ .env for this host)

This build changes H5 only. After unzip, hard refresh (Ctrl+F5).
Check:
  https://sistermart.vip/
  https://sistermart.vip/mock/cat-bracelet.png
  https://sistermart.vip/mock/cat-necklace.png
