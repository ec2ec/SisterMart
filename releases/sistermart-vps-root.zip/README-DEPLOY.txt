SisterMart VPS root overlay package
====================================
Extract at FTP/website ROOT (overwrite):

  unzip -o sistermart-vps-root.zip

Layout:
  /                 H5
  /admin/           Admin
  /mock/            banners, catalog icons, product images
  /products/        product static assets
  /api/index.php    API entry
  /sm-backend/      ThinkPHP app (+ .env for this host)

After unzip: hard refresh browser (Ctrl+F5).
