<?php

declare(strict_types=1);

namespace app\controller\api;

use app\controller\ApiController;
use app\service\TabbarService;
use think\Response;

class Tabbar extends ApiController
{
    public function index(): Response
    {
        return $this->run(fn () => (new TabbarService())->read());
    }
}
