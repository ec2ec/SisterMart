SisterMart H5 delta — 訂單中心 /orders Tab 真實角標
================================================

僅含 H5 靜態（不動 API；counts 接口本已存在）。

【備份】
  mkdir -p ~/sm-h5-backup-$(date +%Y%m%d%H%M)
  cp -a index.html assets ~/sm-h5-backup-XXXX/

【部署】
  unzip -o sistermart-vps-h5-order-badges-delta.zip
  硬刷新

【驗證】
1. 我的 → 訂單中心五個圖標角標為真實待辦數
2. 進入 /orders → 待付款/待發貨/待收貨/待評價/售後 Tab 有角標（0 不顯示）

資源：index-C5G6KoMG.js  index-B2fXlCrW.css
