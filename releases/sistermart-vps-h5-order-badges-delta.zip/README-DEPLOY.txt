SisterMart H5 — 訂單角標修復（counts 404 回退）
==============================================

根因：線上 GET /api/v1/orders/counts 為 nginx 404（API 未部署該路由），
前端靜默失敗 → 角標全 0。demo 帳號實際有待發貨等訂單。

本包：counts 失敗時改用已有 /orders?status= 與 /aftersales 推算角標。

【備份】mkdir + cp index.html assets
【部署】unzip -o sistermart-vps-h5-order-badges-delta.zip 後硬刷新
【預期 demo】待發貨≈3、待收貨≈1、售後≈2（以線上數據為準）

資源：index-8A415JZT.js  index-B2fXlCrW.css
