SisterMart 訂閱 500 熱修（newsletter/me + newsletter/subscribe）

根因：資料庫缺少 newsletter_subscribers（m27 未執行）。

【最快】只跑 SQL（舊 PHP 也能立刻好）：
  phpMyAdmin 導入 sql/m27_newsletter.sql
  或：mysql -u帳號 -p 庫名 < sql/m27_newsletter.sql

【建議】再覆蓋 PHP（之後缺表會自動建）：
  把 sm-backend/app/service/NewsletterService.php
  覆蓋到網站 sm-backend/app/service/NewsletterService.php
