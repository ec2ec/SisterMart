SisterMart 缺表／缺欄熱修（簽到 + 訂閱 + 頭像）

1) 必做：phpMyAdmin 導入 sql/deploy_all_gaps.sql（一次補齊）
2) 建議：覆蓋 sm-backend/app/service/ 下 NewsletterService.php、CheckinService.php
3) 全量程式請用 sistermart-vps-root.zip
