SisterMart H5 delta — PDP overlay 保滾動（Option 2）
================================================

僅含網站根目錄 H5 靜態文件（不動 API / Admin / sm-backend）。

【上線前務必備份（回滾用）】
在 VPS 網站根執行：
  mkdir -p ~/sm-h5-backup-$(date +%Y%m%d%H%M)
  cp -a index.html assets ~/sm-h5-backup-$(date +%Y%m%d%H%M)/

【部署】
把本 zip 解壓覆蓋到網站根：
  unzip -o sistermart-vps-h5-overlay-delta.zip
硬刷新瀏覽器（Ctrl+Shift+R）。

【驗證】
1. 首頁往下滾一段 → 點商品進商詳
2. 商詳應無底欄、左上有返回箭頭
3. 點返回 → 應回到剛才滾動位置（不要跳頂）

【回滾】
用備份覆蓋回去即可，例如：
  cp -a ~/sm-h5-backup-XXXX/index.html ~/sm-h5-backup-XXXX/assets ./
（路徑換成你實際備份目錄；舊 assets 裡多餘的新 hash 文件可留可刪，不影響）

本次資源：
  index.html
  assets/index-K_sQ13TF.js
  assets/index-DCWzt4FB.css
