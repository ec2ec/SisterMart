<?php
namespace think;
require __DIR__ . '/../sm-backend/vendor/autoload.php';
$http = (new App(__DIR__ . '/../sm-backend/'))->http;
$response = $http->run();
$response->send();
$http->end($response);
