SisterMart 秒殺 — SQL／種子
================================
推薦（一次搞定表+欄位+種子）：
  mysql -uUSER -pPASSWORD DBNAME < deploy_seckill.sql

備選：
  mysql … < m11_seckill.sql
  php m11_seed.php   # 需在 API 根目錄有 vendor/.env

種子商品依賴 products.code = p1 / p4；若沒有，請後台「秒殺活動」手動加商品。
