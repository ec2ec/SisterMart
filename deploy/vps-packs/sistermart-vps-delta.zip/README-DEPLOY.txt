SisterMart 增量包（根目錄解壓）
================================
解壓到網站根：覆蓋 index.html、assets/、admin/、sm-backend/

H5：index-CzCFfSG3.js / index-CGYylhjZ.css
Admin：index-YdzrsB0p.js / index-CwSXfbwG.css

本包含：
- 首頁頁腳三欄 + 文章跳轉／展示；分類標題「商品分類」
- 後台文章頁腳 9 欄編輯
- 商品疊加／真實銷量、SKU 代理價／成本價、秒殺相關 API（若尚未覆蓋）

SQL 請另執行（不在本 zip）：
  deploy_footer_articles.sql
  deploy_product_pricing_sold.sql   （若尚未跑過）
  deploy_seckill.sql                （若尚未跑過）

硬刷新瀏覽器。
