SisterMart H5 seckill delta
1. Backup site root index.html + assets/
2. Unzip over site root (or copy these files)
3. Hard refresh

Files: index-w5uNq3l8.js  index-9SjcEsG9.css
Also run: deploy_seckill.sql
