SisterMart 秒殺 — 合併包（H5 在根目錄）
========================================
解壓後結構：
  index.html / assets/ / .htaccess   ← 網站 H5 根（直接 unzip -o 覆蓋）
  admin/                             ← 後台靜態
  sm-backend/                        ← API SeckillService + SQL
  deploy_seckill.sql

H5 本包必含：
  - 秒殺欄目漸變底色 #f7edf9 → #c3d9fb（左上到右下）
  - 動態倒數毫秒：12:33:24.987
  - 分類在秒殺上方

部署：
1. 備份網站根 index.html + assets/
2. 在網站根：unzip -o sistermart-vps-seckill.zip
   （會寫入 index.html、assets/、admin/、sm-backend/、deploy_seckill.sql）
3. 把 sm-backend/app/service/SeckillService.php 拷到 API 對應路徑
   （若 API 不在同目錄，勿讓 sm-backend/ 留在公開 web 根，可刪或移走）
4. mysql … < deploy_seckill.sql
5. 硬刷新（必要時清 CDN / 強刷 Ctrl+F5）

資源：index-w5uNq3l8.js  index-9SjcEsG9.css
若首頁仍無秒殺區塊：先跑 SQL 或後台建活動（無場次時區塊不顯示）。
