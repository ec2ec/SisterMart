SisterMart 秒殺合併包（H5 在根目錄）
H5：index-D7_3p3wh.js / index-DkZabAxA.css
- 倒數 1rem 粗體 #9b3bfc；標題下「⚡️活動即將開始！」
- 商品價：原價劃線 + 秒殺價
網站根 unzip -o；mysql … < deploy_seckill.sql；硬刷新
