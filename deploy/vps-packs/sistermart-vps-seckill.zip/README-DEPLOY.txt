SisterMart 秒殺合併包
H5：index-BRu7G26z.js / index-CMhu4mnb.css
倒數保留原白底樣式，僅 1rem/粗體/#9b3bfc；標題下提示同標題色
網站根 unzip -o；mysql … < deploy_seckill.sql
