SisterMart 合併包 — 秒殺 UI + 商品銷量／價格欄位
================================================
H5（根目錄）：index-DYv9nO1K.js / index-cHeAvceb.css
Admin：index-DNA1r__w.js / index-OI_BozF9.css

1) 網站根 unzip -o（覆蓋 index.html、assets/、admin/、sm-backend/、*.sql）
2) 將 sm-backend/app/service/*.php 拷到 API 對應路徑
3) 執行 SQL（順序可並行，均可重跑）：
   mysql … < deploy_product_pricing_sold.sql
   mysql … < deploy_seckill.sql
4) 硬刷新

商品：
- 疊加數量 sold_boost（可改）；銷售數量 sold_count（下單+／取消退款-，不可改）
- H5 已售 = (銷售+疊加) 再套 50+
- SKU：售價 price、劃線 compare_at、代理價 agent_price、成本價 cost_price（後者僅後台）
