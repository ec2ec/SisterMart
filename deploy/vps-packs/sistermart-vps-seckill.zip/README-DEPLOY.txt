SisterMart 秒殺 — 合併部署包（H5 + Admin + API + SQL）
====================================================

目錄：
  h5/           → 解壓覆蓋網站 H5 根（index.html + assets/）
  admin/        → 覆蓋後台靜態根 /admin/
  sm-backend/   → API：SeckillService.php + database/*.sql
  deploy_seckill.sql → 與 sm-backend/database/ 同檔，方便直接執行

步驟：
1. 備份線上 H5 的 index.html、assets/，以及 admin/、API 對應檔
2. 覆蓋：
     unzip -o sistermart-vps-seckill.zip
     # 再把 h5/* 拷到網站根；admin/* 拷到 /admin/；
     # sm-backend/app/service/SeckillService.php 拷到 API 對應路徑
3. 執行 SQL（建表 + orders.seckill_item_id + 種子 sk-live/sk-soon）：
     mysql -uUSER -pPASSWORD DBNAME < deploy_seckill.sql
4. 硬刷新瀏覽器

H5 資源：index-w5uNq3l8.js / index-9SjcEsG9.css
種子商品依賴 products.code = p1 / p4；沒有則後台「秒殺活動」手動加。
