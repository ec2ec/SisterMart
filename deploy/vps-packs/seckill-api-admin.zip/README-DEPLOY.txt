SisterMart — 秒殺 API + Admin + SQL
================================
1. 覆蓋 sm-backend/app/service/SeckillService.php
2. 覆蓋網站 admin/（靜態）
3. 執行 SQL：
   mysql -uUSER -pPASSWORD DBNAME < sm-backend/database/deploy_seckill.sql
   （建表、orders.seckill_item_id、種子 sk-live/sk-soon；可重跑）

Admin 資源：index-DtMdIc9x.js index-BdJzOxN1.css
